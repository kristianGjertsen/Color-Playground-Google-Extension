const STYLE_ENGINE_ID = "color-playground-engine";
const STYLE_VARS_ID = "color-playground-vars";
const LEGACY_STYLE_ID = "color-playground-style";
// Lagrede palletter og standardinnstillinger
const DEFAULT_PALETTE = {
    bgPrimary: "#0f172a",
    bgSecondary: "#020617",
    surfaceRaised: "#020617",
    textPrimary: "#e5e7eb",
    textSecondary: "#94a3b8",
    textHeading: "#f8fafc",
    accentPrimary: "#38bdf8",
    accentSecondary: "#22d3ee",
    border: "#334155",
    icon: "#e5e7eb"
};
const DEFAULT_SETTINGS = {
    newSiteDefault: "disabled",
    defaultPalette: DEFAULT_PALETTE
};
const ORIGINAL_MARKER = "__original";
const ROLE_ATTRS = {
    bgPrimary: "data-cp-bg-primary",
    bgSecondary: "data-cp-bg-secondary",
    surfaceRaised: "data-cp-surface-raised",
    textPrimary: "data-cp-text-primary",
    textSecondary: "data-cp-text-secondary",
    textHeading: "data-cp-text-heading",
    accentPrimary: "data-cp-accent-primary",
    accentSecondary: "data-cp-accent-secondary",
    border: "data-cp-border",
    icon: "data-cp-icon"
};
const ALL_ROLE_ATTRS = Object.values(ROLE_ATTRS);
const STORAGE_DEFAULTS = {
    enabled: false,
    sites: {},
    disabledSites: {},
    settings: DEFAULT_SETTINGS,
    bases: {}
};

const ENGINE_CSS_URL = chrome.runtime.getURL("engine.css");
const engineCssPromise = fetch(ENGINE_CSS_URL)
    .then(response => response.text())
    .catch(() => "");

const isRestrictedUrl = (url) => {
    if (!url) return true;
    try {
        const parsed = new URL(url);
        const host = parsed.hostname.toLowerCase();
        if (parsed.protocol === "chrome:" || parsed.protocol === "chrome-extension:") {
            return true;
        }
        if (host === "chrome.google.com" && parsed.pathname.startsWith("/webstore")) {
            return true;
        }
        if (host === "chromewebstore.google.com") {
            return true;
        }
        return false;
    } catch (error) {
        return true;
    }
};

const getHostnameFromUrl = (url) => {
    try {
        return new URL(url).hostname;
    } catch (error) {
        return "*";
    }
};

const normalizePalette = (palette) => ({
    ...DEFAULT_PALETTE,
    ...(palette || {})
});

const paletteToVarsCss = (palette) => {
    const lines = [":root {"];
    const entries = Object.entries(palette || {});
    entries.forEach(([key, value]) => {
        if (!value || key === ORIGINAL_MARKER) return;
        const cssKey = `--${key.replace(/[A-Z]/g, m => "-" + m.toLowerCase())}`;
        lines.push(`  ${cssKey}: ${value};`);
    });
    lines.push("}");
    return lines.join("\n");
};

const applyPaletteToTab = (tabId, palette) => {
    const varsCss = paletteToVarsCss(palette);
    const activeAttrs = Object.entries(ROLE_ATTRS)
        .filter(([key]) => palette && palette[key])
        .map(([, attr]) => attr);
    engineCssPromise.then(engineCss => {
        chrome.scripting.executeScript({
            target: { tabId },
            func: (engineId, varsId, legacyId, engineCssText, varsCssText, allAttrs, enabledAttrs) => {
                const legacy = document.getElementById(legacyId);
                if (legacy) legacy.remove();

                const existingEngine = document.getElementById(engineId);
                if (existingEngine) existingEngine.remove();
                const existingVars = document.getElementById(varsId);
                if (existingVars) existingVars.remove();

                const root = document.head || document.documentElement;
                const rootEl = document.documentElement;

                allAttrs.forEach(attr => {
                    if (enabledAttrs.includes(attr)) {
                        rootEl.setAttribute(attr, "1");
                    } else {
                        rootEl.removeAttribute(attr);
                    }
                });

                const engine = document.createElement("style");
                engine.id = engineId;
                engine.textContent = engineCssText;
                root.appendChild(engine);

                const vars = document.createElement("style");
                vars.id = varsId;
                vars.textContent = varsCssText;
                root.appendChild(vars);
            },
            args: [
                STYLE_ENGINE_ID,
                STYLE_VARS_ID,
                LEGACY_STYLE_ID,
                engineCss,
                varsCss,
                ALL_ROLE_ATTRS,
                activeAttrs
            ]
        });
    });

    chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
            // Installer kun én gang per side
            if (window.__cpButtonMarkerInstalled) {
                window.__cpMarkButtons?.();
                return;
            }
            window.__cpButtonMarkerInstalled = true;

            const isTransparent = (value) =>
                !value ||
                value === "transparent" ||
                value === "rgba(0, 0, 0, 0)" ||
                value === "rgba(0,0,0,0)";

            const toPx = (value) => parseFloat(value) || 0;

            const markButtons = () => {
                document.querySelectorAll("a[href]").forEach(a => {
                    const r = a.getBoundingClientRect();
                    const width = r.width;
                    const height = r.height;
                    if (!width || !height) {
                        a.removeAttribute("data-cp-button");
                        return;
                    }

                    const area = width * height;
                    const style = getComputedStyle(a);
                    const paddingX = toPx(style.paddingLeft) + toPx(style.paddingRight);
                    const borderRadius = toPx(style.borderRadius);
                    const hasBg = !isTransparent(style.backgroundColor);
                    const display = style.display;

                    const looksButtonyWithoutBg = borderRadius >= 10 && paddingX >= 18;

                    // knapper er ofte ikke <button>-element
                    //Skrevet inn kode for å prøve å fange opp lenker som ser ut som knapper
                    const isLikelyButton =
                        height >= 28 &&
                        height <= 72 &&
                        width >= 72 &&
                        width <= 420 &&
                        area <= 90000 &&
                        paddingX >= 12 &&
                        borderRadius >= 6 &&
                        (hasBg || looksButtonyWithoutBg) &&
                        (display === "inline-block" ||
                            display === "inline-flex" ||
                            display === "flex" ||
                            display === "inline");

                    if (isLikelyButton) {
                        a.dataset.cpButton = "true";
                    } else {
                        a.removeAttribute("data-cp-button");
                    }
                });
            };

            window.__cpMarkButtons = markButtons;

            // Throttle kjøringer ved DOM-endringer
            //hadde problemer med at det ble kjørt for ofte på noen sider
            let timer = null;
            const schedule = () => {
                if (timer) return;
                timer = setTimeout(() => {
                    timer = null;
                    markButtons();
                }, 200);
            };

            // Kjør flere ganger etter load for SPA-render
            markButtons();
            [150, 500, 1200, 2500, 5000].forEach(ms => setTimeout(markButtons, ms));

            // Observer DOM og re-kjør når UI endrer seg
            const obs = new MutationObserver(schedule);
            obs.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
            window.__cpButtonObserver = obs;

            window.addEventListener("resize", schedule, { passive: true });
            window.addEventListener("scroll", schedule, { passive: true });
        }
    });

};

const removePaletteFromTab = (tabId) => {
    chrome.scripting.executeScript({
        target: { tabId },
        func: (engineId, varsId, legacyId, allAttrs) => {
            [engineId, varsId, legacyId].forEach(id => {
                const node = document.getElementById(id);
                if (node) node.remove();
            });
            allAttrs.forEach(attr => {
                document.documentElement.removeAttribute(attr);
            });
        },
        args: [STYLE_ENGINE_ID, STYLE_VARS_ID, LEGACY_STYLE_ID, ALL_ROLE_ATTRS]
    });
};

const analyzePageColors = (tabId) =>
    chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
            const elements = [
                document.body,
                ...document.querySelectorAll("main, section, header, footer, nav"),
                ...document.querySelectorAll(
                    "p, h1, h2, h3, h4, h5, a, button, small, time"
                )
            ];

            const PROPS = ["color", "backgroundColor"];
            const colors = new Map();

            elements.forEach(el => {
                const style = getComputedStyle(el);
                const area = el.offsetWidth * el.offsetHeight;

                PROPS.forEach(prop => {
                    const value = style[prop];
                    if (
                        !value ||
                        value === "transparent" ||
                        value.includes("rgba(0, 0, 0, 0)")
                    ) {
                        return;
                    }

                    if (!colors.has(value)) {
                        colors.set(value, {
                            count: 0,
                            usages: []
                        });
                    }

                    const entry = colors.get(value);
                    entry.count++;

                    entry.usages.push({
                        prop,
                        tag: el.tagName,
                        fontSize: parseFloat(style.fontSize) || null,
                        area,
                        isLink: el.tagName === "A",
                        isButton: el.tagName === "BUTTON"
                    });
                });
            });

            const luminance = (rgb) => {
                const [r, g, b] = rgb.match(/\d+/g).map(Number);
                return 0.2126 * r + 0.7152 * g + 0.0722 * b;
            };

            const sorted = [...colors.entries()]
                .sort((a, b) => b[1].count - a[1].count);

            const roles = {
                bgPrimary: null,
                bgSecondary: null,
                surfaceRaised: null,
                textPrimary: null,
                textSecondary: null,
                textHeading: null,
                accentPrimary: null,
                accentSecondary: null,
                border: null,
                icon: null
            };

            for (const [color, data] of sorted) {
                const lum = luminance(color);

                if (!roles.bgPrimary && lum > 210) {
                    roles.bgPrimary = color;
                    continue;
                }

                if (
                    !roles.bgSecondary &&
                    lum > 170 &&
                    data.usages.some(
                        u => u.prop === "backgroundColor" && u.area > 20000
                    )
                ) {
                    roles.bgSecondary = color;
                    continue;
                }

                if (
                    !roles.surfaceRaised &&
                    data.usages.some(u => u.tag === "HEADER" || u.tag === "NAV")
                ) {
                    roles.surfaceRaised = color;
                    continue;
                }

                if (!roles.textPrimary && lum < 90) {
                    roles.textPrimary = color;
                    continue;
                }

                if (
                    !roles.textHeading &&
                    data.usages.some(u => u.tag.startsWith("H"))
                ) {
                    roles.textHeading = color;
                    continue;
                }

                if (!roles.textSecondary && lum >= 90 && lum < 150) {
                    roles.textSecondary = color;
                    continue;
                }

                if (
                    !roles.accentPrimary &&
                    data.usages.some(u => u.isLink || u.isButton)
                ) {
                    roles.accentPrimary = color;
                    continue;
                }

                if (!roles.accentSecondary && lum >= 120 && lum < 200) {
                    roles.accentSecondary = color;
                    continue;
                }

                if (!roles.border && lum >= 120 && lum < 200) {
                    roles.border = color;
                    continue;
                }

                if (!roles.icon) {
                    roles.icon = color;
                }
            }

            return roles;
        }
    });

//Henter ut data fra storage, for å huske palleten som og enablesettings 
const getStorage = () =>
    new Promise(resolve => chrome.storage.local.get(STORAGE_DEFAULTS, resolve));

const queryActiveTab = () =>
    new Promise(resolve => {
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
            if (tabs && tabs.length) {
                resolve(tabs[0]);
                return;
            }
            chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
                resolve(tab);
            });
        });
    });

const ensureBasePalette = async (tabId, hostname, data, fallback) => {
    const baseMap = data.bases || {};
    if (baseMap[hostname]) {
        return normalizePalette(baseMap[hostname]);
    }
    try {
        const [res] = await analyzePageColors(tabId);
        if (res && res.result) {
            const base = normalizePalette(res.result);
            const nextBases = { ...baseMap, [hostname]: base };
            chrome.storage.local.set({ bases: nextBases });
            return base;
        }
    } catch (error) {
        return normalizePalette(fallback);
    }
    return normalizePalette(fallback);
};

const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const captureOriginalForTab = async (tabId, hostname) => {
    let tab = null;
    if (tabId) {
        try {
            tab = await chrome.tabs.get(tabId);
        } catch (error) {
            tab = null;
        }
    }
    if (!tab) {
        tab = await queryActiveTab();
    }
    if (!tab || !tab.id || !tab.url || isRestrictedUrl(tab.url)) return;
    const resolvedHostname = hostname || getHostnameFromUrl(tab.url);
    if (!resolvedHostname || resolvedHostname === "*") return;

    // Fjern eventuell tidligere palett
    removePaletteFromTab(tab.id);
    await wait(80);

    let detected = null;
    try {
        const [res] = await analyzePageColors(tab.id);
        if (res && res.result) {
            detected = normalizePalette(res.result);
        }
    } catch (error) {
        detected = null;
    }

    const data = await getStorage();
    const baseMap = data.bases || {};
    const siteMap = data.sites || {};
    const disabledMap = { ...(data.disabledSites || {}) };
    if (disabledMap[resolvedHostname]) {
        delete disabledMap[resolvedHostname];
    }

    const nextBases = { ...baseMap };
    if (detected) {
        nextBases[resolvedHostname] = detected;
    }
    const nextSites = {
        ...siteMap,
        [resolvedHostname]: { [ORIGINAL_MARKER]: true }
    };

    await new Promise(resolve =>
        chrome.storage.local.set(
            { bases: nextBases, sites: nextSites, disabledSites: disabledMap },
            resolve
        )
    );

    await syncHostname(resolvedHostname);
};

const resolvePaletteForTab = async (url, data) => {
    if (!data.enabled) return null;
    if (!url || isRestrictedUrl(url)) return null;
    const hostname = getHostnameFromUrl(url);
    if (data.disabledSites && data.disabledSites[hostname]) return null;

    const siteMap = data.sites || {};
    const siteEntry = siteMap[hostname] || {};
    const { [ORIGINAL_MARKER]: original, ...overrides } = siteEntry;
    const hasOverrides = Object.keys(overrides).length > 0;
    const resolvedSettings = { ...DEFAULT_SETTINGS, ...(data.settings || {}) };
    const fallbackPalette =
        resolvedSettings.defaultPalette || siteMap["*"] || DEFAULT_PALETTE;
    if (!hasOverrides && original) {
        return {};
    }
    if (hasOverrides) {
        return overrides;
    }
    if (!hasOverrides && resolvedSettings.newSiteDefault === "disabled") {
        return null;
    }
    return normalizePalette(fallbackPalette);
};

const syncTabWithData = async (tab, data, options = {}) => {
    if (!tab || !tab.id || !tab.url || isRestrictedUrl(tab.url)) return;
    if (options.ensureBase) {
        const hostname = getHostnameFromUrl(tab.url);
        await ensureBasePalette(tab.id, hostname, data, DEFAULT_PALETTE);
    }
    const palette = await resolvePaletteForTab(tab.url, data);
    if (!palette) {
        removePaletteFromTab(tab.id);
        return;
    }
    if (Object.keys(palette).length === 0) {
        removePaletteFromTab(tab.id);
        return;
    }
    applyPaletteToTab(tab.id, palette);
};

const syncAllTabs = async () => {
    const data = await getStorage();
    const tabs = await new Promise(resolve => chrome.tabs.query({}, resolve));
    await Promise.all(tabs.map(tab => syncTabWithData(tab, data)));
};

const syncTabById = async (tabId, options = {}) => {
    if (!tabId) return;
    let tab = null;
    try {
        tab = await chrome.tabs.get(tabId);
    } catch (error) {
        tab = null;
    }
    if (!tab || !tab.url || isRestrictedUrl(tab.url)) return;
    const data = await getStorage();
    await syncTabWithData(tab, data, options);
};

const syncHostname = async (hostname) => {
    if (!hostname || hostname === "*") return;
    const data = await getStorage();
    const tabs = await new Promise(resolve => chrome.tabs.query({}, resolve));
    const matches = tabs.filter(
        tab =>
            tab &&
            tab.url &&
            !isRestrictedUrl(tab.url) &&
            getHostnameFromUrl(tab.url) === hostname
    );
    await Promise.all(matches.map(tab => syncTabWithData(tab, data)));
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.type) return;
    if (message.type === "sync-all") {
        syncAllTabs().then(() => sendResponse({ ok: true }));
        return true;
    }
    if (message.type === "sync-hostname") {
        syncHostname(message.hostname).then(() => sendResponse({ ok: true }));
        return true;
    }
    if (message.type === "capture-original") {
        captureOriginalForTab(message.tabId, message.hostname).then(() =>
            sendResponse({ ok: true })
        );
        return true;
    }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const isComplete = changeInfo.status === "complete";
    const hasUrlUpdate = Boolean(changeInfo.url);
    if (!isComplete && !hasUrlUpdate) return;
    syncTabById(tabId, { ensureBase: isComplete });
});

chrome.tabs.onActivated.addListener(({ tabId }) => {
    syncTabById(tabId);
});

// AI-generert palette, via ekstern Api kall til Google Cloud Function
//lite tester av svar, men testes i API scriptet
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type !== "AI_GENERATE_PALETTE") return;

    fetch("https://colorplayground.kristiangjertsen5.workers.dev", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: msg.prompt })
    })
        .then(r => r.json())
        .then((response) => {
            const { palette } = response || {};
            if (!palette) return;

            chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
                if (!tab?.id || !tab.url) return;

                const hostname = new URL(tab.url).hostname;

                chrome.storage.local.get(STORAGE_DEFAULTS, (data) => {
                    const sites = { ...(data.sites || {}) };
                    sites[hostname] = palette;

                    chrome.storage.local.set({ sites }, () => {
                        applyPaletteToTab(tab.id, normalizePalette(palette));
                    });
                });
            });
        })
        .catch(err => {
            console.error("AI palette error:", err);
        });
});
